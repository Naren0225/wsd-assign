# Q11-tasks-CRUD-react

```bash
 git clone https://github.com/Punithify/Q11-tasks-CRUD-react.git
```

## Installation

Install vite-project with npm

```bash
  cd Q11-tasks-CRUD-react
  npm install
  npm run dev
```
