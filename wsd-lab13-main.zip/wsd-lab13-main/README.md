# wsd-lab13
![1](https://github.com/Vishnu-comp/wsd-lab13/assets/82950219/c6834336-5513-4d26-92b6-321766087b8d)

